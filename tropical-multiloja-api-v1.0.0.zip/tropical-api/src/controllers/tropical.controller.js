/**
 * Tropical Controller
 * Controlador de rotas para orçamentos
 * 
 * Tropical Multi Loja API v1.0.0
 * Desenvolvido por Soul Plus Digital
 */

const tropicalService = require('../services/tropical.service');

/**
 * Processa JSON de produtos e gera orçamento formatado em texto
 * 
 * @route POST /api/tropical/products
 * @param {Object} req.body.produtos - JSON com arrays "encontrados" e "nao_encontrados"
 * @returns {Object} { message: string } - Orçamento formatado em texto
 */
exports.processProductsText = async (req, res, next) => {
    try {
        const { produtos } = req.body;

        if (!produtos) {
            return res.status(400).json({ 
                error: 'Campo "produtos" é obrigatório',
                exemplo: {
                    produtos: {
                        encontrados: [
                            { codigo: '12345', quantidade: 2, descricao: 'Produto Exemplo' }
                        ],
                        nao_encontrados: [
                            { descricao: 'Produto não localizado' }
                        ]
                    }
                }
            });
        }

        const result = await tropicalService.processProductQuoteText(produtos);
        
        if (result.error) {
            return res.status(500).json(result);
        }

        return res.json(result);
    } catch (error) {
        next(error);
    }
};

/**
 * Processa JSON de produtos e gera orçamento em PDF
 * 
 * @route POST /api/tropical/productsToPDF
 * @param {Object} req.body.produtos - JSON com arrays "encontrados" e "nao_encontrados"
 * @returns {Object} { fileId: string } - ID do arquivo PDF gerado
 */
exports.processProductsPDF = async (req, res, next) => {
    try {
        const { produtos } = req.body;

        if (!produtos) {
            return res.status(400).json({ 
                error: 'Campo "produtos" é obrigatório',
                exemplo: {
                    produtos: {
                        encontrados: [
                            { codigo: '12345', quantidade: 2, descricao: 'Produto Exemplo' }
                        ],
                        nao_encontrados: [
                            { descricao: 'Produto não localizado' }
                        ]
                    }
                }
            });
        }

        const result = await tropicalService.processProductQuotePDF(produtos);
        
        if (result.error) {
            return res.status(500).json(result);
        }

        return res.json(result);
    } catch (error) {
        next(error);
    }
};

/**
 * Health check do serviço
 * 
 * @route GET /api/tropical/health
 * @returns {Object} Status do serviço
 */
exports.healthCheck = (req, res) => {
    res.json({
        status: 'ok',
        service: 'Tropical Multi Loja API',
        version: '1.0.0',
        timestamp: new Date().toISOString(),
    });
};
