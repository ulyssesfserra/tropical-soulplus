/**
 * Tropical Service
 * Serviço de processamento de orçamentos
 * 
 * Tropical Multi Loja API v1.0.0
 * Desenvolvido por Soul Plus Digital
 */

const axios = require('axios');
const PDFDocument = require('pdfkit');
const config = require('../../config');

// =============================================================================
// FUNÇÕES DE AUTENTICAÇÃO
// =============================================================================

/**
 * Obtém o token de autenticação da API Tropical
 * @returns {Promise<string>} Token de acesso
 */
async function getAuthToken() {
    const url = `${config.api.baseUrl}/cisspoder-auth/oauth/token`;

    const formData = new URLSearchParams();
    formData.append('client_id', config.auth.clientId);
    formData.append('grant_type', config.auth.grantType);
    formData.append('client_secret', config.auth.clientSecret);
    formData.append('username', config.auth.username);
    formData.append('password', config.auth.password);

    const response = await axios.post(url, formData, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });

    return response.data.access_token;
}

// =============================================================================
// FUNÇÕES DE CONSULTA DE PRODUTOS
// =============================================================================

/**
 * Busca descrição do produto pelo código
 * @param {string} token - Token de autenticação
 * @param {number} productId - ID do produto
 * @returns {Promise<string|null>} Descrição do produto
 */
async function getProductDescription(token, productId) {
    const url = `${config.api.baseUrl}/cisspoder-service/cad_produtos`;

    const payload = {
        page: 1,
        clausulas: [
            {
                campo: 'idproduto',
                valor: productId,
                operadorlogico: 'AND',
                operador: 'IGUAL',
            },
        ],
    };

    const response = await axios.post(url, payload, {
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    });

    if (response.data?.data && response.data.data.length > 0) {
        return response.data.data[0].descrcomproduto;
    }

    return null;
}

/**
 * Busca preço do produto pelo código
 * @param {string} token - Token de autenticação
 * @param {number} productId - ID do produto
 * @returns {Promise<number|null>} Preço do produto
 */
async function getProductPrice(token, productId) {
    const url = `${config.api.baseUrl}/cisspoder-service/precos_custos_produtos_empresa`;

    const payload = {
        page: 1,
        clausulas: [
            {
                campo: 'idproduto',
                valor: productId,
                operadorlogico: 'AND',
                operador: 'IGUAL',
            },
            {
                campo: 'idempresa',
                valor: config.api.empresaId,
                operadorlogico: 'AND',
                operador: 'IGUAL',
            },
        ],
    };

    const response = await axios.post(url, payload, {
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    });

    if (response.data?.data && response.data.data.length > 0) {
        return response.data.data[0].valprecovarejo;
    }

    return null;
}

// =============================================================================
// FUNÇÕES DE FORMATAÇÃO
// =============================================================================

/**
 * Formata o preço para exibição (ex: 9,90)
 * @param {number|null} price - Preço a ser formatado
 * @returns {string|null} Preço formatado
 */
function formatPrice(price) {
    if (price === null || price === undefined) {
        return null;
    }
    return parseFloat(price).toFixed(2).replace('.', ',');
}

/**
 * Formata a data no formato "DD/MM/YYYY"
 * @param {Date} date - Data a ser formatada
 * @returns {string} Data formatada
 */
function formatDate(date) {
    const dia = String(date.getDate()).padStart(2, '0');
    const mes = String(date.getMonth() + 1).padStart(2, '0');
    const ano = date.getFullYear();
    return `${dia}/${mes}/${ano}`;
}

/**
 * Formata a data por extenso "Manaus, DD de mês de YYYY"
 * @param {Date} date - Data a ser formatada
 * @returns {string} Data formatada por extenso
 */
function formatDateExtended(date) {
    const meses = [
        'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
        'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
    ];
    const dia = date.getDate();
    const mes = meses[date.getMonth()];
    const ano = date.getFullYear();
    return `Manaus, ${dia} de ${mes} de ${ano}.`;
}

// =============================================================================
// FUNÇÕES DE GERAÇÃO DE PDF
// =============================================================================

/**
 * Baixa a imagem do logo e retorna como buffer
 * @returns {Promise<Buffer|null>} Buffer da imagem
 */
async function downloadLogo() {
    try {
        const response = await axios.get(config.logoUrl, { responseType: 'arraybuffer' });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('Erro ao baixar logo:', error.message);
        return null;
    }
}

/**
 * Desenha o cabeçalho do PDF
 * @param {PDFDocument} doc - Documento PDF
 * @param {Buffer|null} logoBuffer - Buffer do logo
 * @param {string} dataEmissao - Data de emissão
 * @param {string} dataValidade - Data de validade
 * @param {number} pageNumber - Número da página
 * @returns {number} Posição Y após o cabeçalho
 */
function drawHeader(doc, logoBuffer, dataEmissao, dataValidade, pageNumber) {
    const pageWidth = doc.page.width;
    const marginLeft = 50;
    const marginRight = 50;
    const contentWidth = pageWidth - marginLeft - marginRight;
    const colWidth = contentWidth / 3;
    const headerTop = 40;

    // Coluna 1: Logo
    if (logoBuffer) {
        doc.image(logoBuffer, marginLeft, headerTop, { width: 80, height: 60 });
    }

    // Coluna 2: Dados da empresa
    const col2X = marginLeft + colWidth;
    doc.fontSize(8).font('Helvetica-Bold');
    doc.text(config.empresa.nome, col2X, headerTop, { width: colWidth, align: 'center' });
    doc.font('Helvetica').fontSize(7);
    doc.text(`CNPJ: ${config.empresa.cnpj}`, col2X, headerTop + 12, { width: colWidth, align: 'center' });
    doc.text(config.empresa.endereco, col2X, headerTop + 22, { width: colWidth, align: 'center' });
    doc.text(`${config.empresa.cidade} - ${config.empresa.cep}`, col2X, headerTop + 32, { width: colWidth, align: 'center' });

    // Coluna 3: Dados do orçamento
    const col3X = marginLeft + colWidth * 2;
    doc.fontSize(8).font('Helvetica-Bold');
    doc.text('ORÇAMENTO', col3X, headerTop, { width: colWidth, align: 'center' });
    doc.font('Helvetica').fontSize(7);
    doc.text(`Emissão: ${dataEmissao}`, col3X, headerTop + 15, { width: colWidth, align: 'center' });
    doc.text(`Validade: ${dataValidade}`, col3X, headerTop + 25, { width: colWidth, align: 'center' });
    doc.text(`Página: ${pageNumber}`, col3X, headerTop + 35, { width: colWidth, align: 'center' });

    // Linha separadora
    const lineY = headerTop + 70;
    doc.moveTo(marginLeft, lineY)
        .lineTo(pageWidth - marginRight, lineY)
        .stroke();

    return lineY + 15;
}

/**
 * Gera o PDF do orçamento
 * @param {Array} itensProcessados - Itens encontrados e processados
 * @param {Array} naoEncontrados - Itens não encontrados
 * @param {number} totalGeral - Total geral do orçamento
 * @returns {Promise<Buffer>} Buffer do PDF gerado
 */
async function generatePDF(itensProcessados, naoEncontrados, totalGeral) {
    const logoBuffer = await downloadLogo();
    const now = new Date();
    const dataEmissao = formatDate(now);
    const validade = new Date(now);
    validade.setDate(validade.getDate() + 2);
    const dataValidade = formatDate(validade);

    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({
                size: 'A4',
                margin: 50,
                bufferPages: true,
            });

            const chunks = [];
            doc.on('data', chunk => chunks.push(chunk));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            let pageNumber = 1;
            let currentY = drawHeader(doc, logoBuffer, dataEmissao, dataValidade, pageNumber);

            const marginLeft = 50;
            const marginRight = 50;
            const pageWidth = doc.page.width;
            const pageHeight = doc.page.height;
            const bottomMargin = 100;

            // Função para verificar se precisa de nova página
            const checkNewPage = requiredHeight => {
                if (currentY + requiredHeight > pageHeight - bottomMargin) {
                    doc.addPage();
                    pageNumber += 1;
                    currentY = drawHeader(doc, logoBuffer, dataEmissao, dataValidade, pageNumber);
                }
            };

            // Título Itens Encontrados
            if (itensProcessados.length > 0) {
                checkNewPage(30);
                doc.fontSize(11).font('Helvetica-Bold');
                doc.text('ITENS ENCONTRADOS:', marginLeft, currentY);
                currentY += 20;

                // Itens
                itensProcessados.forEach((item, index) => {
                    checkNewPage(45);

                    const precoStr = item.preco !== null ? `R$ ${item.preco}` : 'Preço indisponível';
                    const subtotalStr = item.preco !== null ? `R$ ${item.subtotal}` : 'Indisponível';

                    doc.fontSize(9).font('Helvetica-Bold');
                    doc.text(`${index + 1}) ${item.descricaoOriginal} - Qtde ${item.quantidade}`, marginLeft, currentY, {
                        width: pageWidth - marginLeft - marginRight,
                    });
                    currentY += 12;

                    doc.fontSize(8).font('Helvetica');
                    doc.text(`Código: ${item.codigo} - ${item.descricaoAPI} - Preço: ${precoStr} - Subtotal: ${subtotalStr}`, marginLeft, currentY, {
                        width: pageWidth - marginLeft - marginRight,
                    });
                    currentY += 18;
                });
            }

            // Itens não encontrados
            if (naoEncontrados.length > 0) {
                checkNewPage(30);
                currentY += 10;
                doc.fontSize(11).font('Helvetica-Bold');
                doc.text('ITENS NÃO ENCONTRADOS:', marginLeft, currentY);
                currentY += 20;

                naoEncontrados.forEach(item => {
                    checkNewPage(15);
                    doc.fontSize(9).font('Helvetica');
                    doc.text(`- ${item.descricao}`, marginLeft, currentY);
                    currentY += 12;
                });
            }

            // Linha separadora antes do total
            checkNewPage(80);
            currentY += 15;
            doc.moveTo(marginLeft, currentY)
                .lineTo(pageWidth - marginRight, currentY)
                .stroke();
            currentY += 15;

            // Total
            doc.fontSize(12).font('Helvetica-Bold');
            doc.text(`Valor total: R$ ${formatPrice(totalGeral)}`, marginLeft, currentY);
            currentY += 20;

            // Mensagem de validade
            doc.fontSize(9).font('Helvetica');
            doc.text('Observação: esse orçamento tem validade de 2 dias.', marginLeft, currentY);
            currentY += 30;

            // Data por extenso
            doc.fontSize(10).font('Helvetica-Oblique');
            doc.text(formatDateExtended(now), marginLeft, currentY);

            doc.end();
        } catch (error) {
            reject(error);
        }
    });
}

/**
 * Faz upload do PDF e retorna o fileId
 * @param {Buffer} pdfBuffer - Buffer do PDF
 * @returns {Promise<string>} ID do arquivo
 */
async function uploadPDF(pdfBuffer) {
    const base64Data = pdfBuffer.toString('base64');

    const payload = {
        queueId: config.upload.queueId,
        apiKey: config.upload.apiKey,
        data: base64Data,
        fileName: 'Orçamento Lista Material Tropical Multi Loja.pdf',
        title: 'Orçamento Lista Material Tropical Multi Loja',
        mimeType: 'application/pdf',
        saveToGallery: false,
    };

    const response = await axios.post(config.upload.url, payload, {
        headers: {
            'Content-Type': 'application/json',
        },
    });

    return response.data.fileId;
}

// =============================================================================
// FUNÇÕES DE PROCESSAMENTO DE PRODUTOS
// =============================================================================

/**
 * Processa os itens do orçamento
 * @param {Object} data - Dados com encontrados e não encontrados
 * @returns {Promise<Object>} Itens processados e total
 */
async function processItems(data) {
    const encontrados = data.encontrados || [];
    const naoEncontrados = data.nao_encontrados || [];

    // Obtém o token de autenticação
    let token;
    try {
        token = await getAuthToken();
    } catch (error) {
        console.error('Erro ao obter token de autenticação:', error.message);
        throw new Error('Erro ao obter token de autenticação');
    }

    // Processa itens encontrados
    const itensProcessados = [];
    let totalGeral = 0;

    for (const item of encontrados) {
        const productId = parseInt(item.codigo, 10);
        const quantidade = parseInt(item.quantidade, 10) || 1;
        const descricaoOriginal = item.descricao || '';

        let descricaoAPI = null;
        let preco = null;
        let precoNumerico = 0;

        if (!Number.isNaN(productId)) {
            try {
                descricaoAPI = await getProductDescription(token, productId);
            } catch (error) {
                console.error(`Erro ao buscar descrição do produto ${item.codigo}:`, error.message);
            }

            try {
                preco = await getProductPrice(token, productId);
                if (preco !== null) {
                    precoNumerico = parseFloat(preco);
                }
            } catch (error) {
                console.error(`Erro ao buscar preço do produto ${item.codigo}:`, error.message);
            }
        }

        const subtotal = precoNumerico * quantidade;
        totalGeral += subtotal;

        itensProcessados.push({
            descricaoOriginal,
            descricaoAPI: descricaoAPI || 'Produto não encontrado',
            quantidade,
            codigo: item.codigo,
            preco: formatPrice(preco),
            precoNumerico,
            subtotal: formatPrice(subtotal),
        });
    }

    return {
        itensProcessados,
        naoEncontrados,
        totalGeral,
    };
}

// =============================================================================
// FUNÇÕES PÚBLICAS (ENDPOINTS)
// =============================================================================

/**
 * Processa o JSON de produtos e gera orçamento em texto
 * Endpoint: POST /api/tropical/products
 * @param {string|Object} jsonText - JSON com produtos
 * @returns {Promise<Object>} Mensagem formatada
 */
async function processProductQuoteText(jsonText) {
    let data;

    // Parse do JSON
    try {
        data = typeof jsonText === 'string' ? JSON.parse(jsonText) : jsonText;
    } catch (error) {
        console.error('Erro ao fazer parse do JSON:', error.message);
        return { error: 'Erro ao processar JSON de entrada' };
    }

    // Processa os itens
    let processedData;
    try {
        processedData = await processItems(data);
    } catch (error) {
        return { error: error.message };
    }

    const { itensProcessados, naoEncontrados, totalGeral } = processedData;

    // Monta a mensagem formatada
    let message = 'Perfeito! 🌺 Segue o orçamento:\n\n';

    // Itens encontrados
    if (itensProcessados.length > 0) {
        message += 'ITENS ENCONTRADOS:\n';

        itensProcessados.forEach((item, index) => {
            const precoStr = item.preco !== null ? `R$ ${item.preco}` : 'Preço indisponível';
            const subtotalStr = item.preco !== null ? `R$ ${item.subtotal}` : 'Indisponível';

            message += `${index + 1}) ${item.descricaoOriginal} - Qtde ${item.quantidade}\n`;
            message += `Código: ${item.codigo} - ${item.descricaoAPI} - Preço: ${precoStr} - Subtotal: ${subtotalStr}\n`;

            if (index < itensProcessados.length - 1) {
                message += '\n';
            }
        });
    }

    // Itens não encontrados
    if (naoEncontrados.length > 0) {
        message += '\nITENS NÃO ENCONTRADOS:\n';

        naoEncontrados.forEach(item => {
            message += `- ${item.descricao}\n`;
        });
    }

    // Total
    message += `\nValor total: R$ ${formatPrice(totalGeral)}\n`;

    // Data e validade
    message += `\n*Data do orçamento: ${formatDate(new Date())}*\n`;
    message += '*Observação: esse orçamento tem validade de 2 dias.*\n';
    message += '\nSe deseja mais informações, nosso time de vendas está à disposição para concluir seu orçamento ou alterar itens.\n';

    return { message };
}

/**
 * Processa o JSON de produtos, gera PDF e retorna fileId
 * Endpoint: POST /api/tropical/productsToPDF
 * @param {string|Object} jsonText - JSON com produtos
 * @returns {Promise<Object>} fileId do PDF gerado
 */
async function processProductQuotePDF(jsonText) {
    let data;

    // Parse do JSON
    try {
        data = typeof jsonText === 'string' ? JSON.parse(jsonText) : jsonText;
    } catch (error) {
        console.error('Erro ao fazer parse do JSON:', error.message);
        return { error: 'Erro ao processar JSON de entrada' };
    }

    // Processa os itens
    let processedData;
    try {
        processedData = await processItems(data);
    } catch (error) {
        return { error: error.message };
    }

    const { itensProcessados, naoEncontrados, totalGeral } = processedData;

    // Gera o PDF
    let pdfBuffer;
    try {
        pdfBuffer = await generatePDF(itensProcessados, naoEncontrados, totalGeral);
    } catch (error) {
        console.error('Erro ao gerar PDF:', error.message);
        return { error: 'Erro ao gerar PDF do orçamento' };
    }

    // Faz upload do PDF
    let fileId;
    try {
        fileId = await uploadPDF(pdfBuffer);
    } catch (error) {
        console.error('Erro ao fazer upload do PDF:', error.message);
        return { error: 'Erro ao fazer upload do PDF' };
    }

    return { fileId };
}

// =============================================================================
// EXPORTAÇÕES
// =============================================================================

module.exports = {
    processProductQuoteText,
    processProductQuotePDF,
};
