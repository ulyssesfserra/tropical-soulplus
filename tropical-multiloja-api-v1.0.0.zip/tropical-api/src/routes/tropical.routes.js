/**
 * Tropical Routes
 * Definição das rotas da API
 * 
 * Tropical Multi Loja API v1.0.0
 * Desenvolvido por Soul Plus Digital
 */

const router = require('express').Router();
const controller = require('../controllers/tropical.controller');

// Health check
router.get('/health', controller.healthCheck);

// Gera orçamento em texto
router.post('/products', controller.processProductsText);

// Gera orçamento em PDF
router.post('/productsToPDF', controller.processProductsPDF);

module.exports = router;
