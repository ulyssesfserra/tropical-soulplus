/**
 * Tropical Multi Loja API
 * Aplicação principal
 * 
 * Versão: 1.0.0
 * Desenvolvido por Soul Plus Digital
 * 
 * Endpoints disponíveis:
 * - GET  /api/tropical/health       - Health check
 * - POST /api/tropical/products     - Gera orçamento em texto
 * - POST /api/tropical/productsToPDF - Gera orçamento em PDF
 */

const express = require('express');
const cors = require('cors');
const config = require('../config');
const tropicalRoutes = require('./routes/tropical.routes');

// Inicializa o app
const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging de requisições
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path}`);
    next();
});

// Rota raiz
app.get('/', (req, res) => {
    res.json({
        name: 'Tropical Multi Loja API',
        version: '1.0.0',
        description: 'API de Orçamentos para Tropical Multi Loja',
        developer: 'Soul Plus Digital',
        endpoints: {
            health: 'GET /api/tropical/health',
            products: 'POST /api/tropical/products',
            productsToPDF: 'POST /api/tropical/productsToPDF',
        },
        documentation: 'Consulte o README.md para mais informações',
    });
});

// Rotas da API
app.use('/api/tropical', tropicalRoutes);

// Rota legada (compatibilidade)
app.use('/int/tropical', tropicalRoutes);

// Middleware de erro 404
app.use((req, res) => {
    res.status(404).json({
        error: 'Rota não encontrada',
        path: req.path,
        method: req.method,
    });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
    console.error('Erro na aplicação:', err);
    
    res.status(err.status || 500).json({
        error: err.message || 'Erro interno do servidor',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    });
});

// Inicia o servidor
const PORT = config.port;

app.listen(PORT, () => {
    console.log('');
    console.log('╔═══════════════════════════════════════════════════════════╗');
    console.log('║                                                           ║');
    console.log('║          TROPICAL MULTI LOJA API v1.0.0                   ║');
    console.log('║          Desenvolvido por Soul Plus Digital               ║');
    console.log('║                                                           ║');
    console.log('╠═══════════════════════════════════════════════════════════╣');
    console.log(`║  Servidor rodando em: http://localhost:${PORT}              ║`);
    console.log('║                                                           ║');
    console.log('║  Endpoints:                                               ║');
    console.log('║  - GET  /api/tropical/health                              ║');
    console.log('║  - POST /api/tropical/products                            ║');
    console.log('║  - POST /api/tropical/productsToPDF                       ║');
    console.log('║                                                           ║');
    console.log('╚═══════════════════════════════════════════════════════════╝');
    console.log('');
});

module.exports = app;
