/**
 * Configurações da Aplicação
 * Tropical Multi Loja API
 * Desenvolvido por Soul Plus Digital
 */

require('dotenv').config();

module.exports = {
    // Servidor
    port: process.env.PORT || 3000,

    // API Tropical
    api: {
        baseUrl: process.env.API_BASE_URL || 'https://cim2-app-tropical-multiloja.guidetti.com.br',
        empresaId: parseInt(process.env.EMPRESA_ID, 10) || 3,
    },

    // Autenticação
    auth: {
        clientId: process.env.AUTH_CLIENT_ID || 'cisspoder-oauth',
        grantType: process.env.AUTH_GRANT_TYPE || 'password',
        clientSecret: process.env.AUTH_CLIENT_SECRET || 'poder7547',
        username: process.env.AUTH_USERNAME || 'SOULPLUS',
        password: process.env.AUTH_PASSWORD || 'S0uL$25',
    },

    // Upload
    upload: {
        url: process.env.UPLOAD_URL || 'https://tropical.soulplus.chat/int/uploadFile',
        queueId: parseInt(process.env.QUEUE_ID, 10) || 32,
        apiKey: process.env.UPLOAD_API_KEY || '@soulplus-api',
    },

    // Logo
    logoUrl: process.env.LOGO_URL || 'https://storage-files-api.soulplus.digital/logo-39-tropical.png',

    // Informações da empresa para PDF
    empresa: {
        nome: process.env.EMPRESA_NOME || 'Comercio de Miudezas Bandeira Ltda',
        cnpj: process.env.EMPRESA_CNPJ || '84.450.212/0001-60',
        endereco: process.env.EMPRESA_ENDERECO || 'Rua Saldanha Marinho 530 - Centro',
        cidade: process.env.EMPRESA_CIDADE || 'Manaus - AM',
        cep: process.env.EMPRESA_CEP || 'CEP 69010-040',
    },
};
